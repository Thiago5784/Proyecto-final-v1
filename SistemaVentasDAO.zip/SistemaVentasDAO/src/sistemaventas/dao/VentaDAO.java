
package sistemaventas.dao;

import sistemaventas.entity.Venta;
import java.util.*;

public class VentaDAO implements IBaseDAO<Venta> {
    private List<Venta> ventas = new ArrayList<>();

    public void insertar(Venta venta) { ventas.add(venta); }

    public void actualizar(Venta venta) {
        for (int i = 0; i < ventas.size(); i++) {
            if (ventas.get(i).getId() == venta.getId()) {
                ventas.set(i, venta);
                return;
            }
        }
    }

    public void eliminar(int id) {
        ventas.removeIf(v -> v.getId() == id);
    }

    public Venta obtenerPorId(int id) {
        return ventas.stream().filter(v -> v.getId() == id).findFirst().orElse(null);
    }

    public List<Venta> obtenerTodos() { return ventas; }
}
