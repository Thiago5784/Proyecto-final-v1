
package sistemaventas.dao;

import sistemaventas.entity.DetalleVenta;
import java.util.*;

public class DetalleVentaDAO implements IBaseDAO<DetalleVenta> {
    private List<DetalleVenta> detalles = new ArrayList<>();

    public void insertar(DetalleVenta detalle) { detalles.add(detalle); }

    public void actualizar(DetalleVenta detalle) {
        for (int i = 0; i < detalles.size(); i++) {
            if (detalles.get(i).getId() == detalle.getId()) {
                detalles.set(i, detalle);
                return;
            }
        }
    }

    public void eliminar(int id) {
        detalles.removeIf(d -> d.getId() == id);
    }

    public DetalleVenta obtenerPorId(int id) {
        return detalles.stream().filter(d -> d.getId() == id).findFirst().orElse(null);
    }

    public List<DetalleVenta> obtenerTodos() { return detalles; }
}
