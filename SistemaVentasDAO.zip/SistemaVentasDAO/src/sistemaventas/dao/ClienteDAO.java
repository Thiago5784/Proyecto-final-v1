
package sistemaventas.dao;

import sistemaventas.entity.Cliente;
import java.util.*;

public class ClienteDAO implements IBaseDAO<Cliente> {
    private List<Cliente> clientes = new ArrayList<>();

    public void insertar(Cliente cliente) { clientes.add(cliente); }

    public void actualizar(Cliente cliente) {
        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getId() == cliente.getId()) {
                clientes.set(i, cliente);
                return;
            }
        }
    }

    public void eliminar(int id) {
        clientes.removeIf(c -> c.getId() == id);
    }

    public Cliente obtenerPorId(int id) {
        return clientes.stream().filter(c -> c.getId() == id).findFirst().orElse(null);
    }

    public List<Cliente> obtenerTodos() { return clientes; }
}
