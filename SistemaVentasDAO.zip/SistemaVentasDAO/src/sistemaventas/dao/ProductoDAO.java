
package sistemaventas.dao;

import sistemaventas.entity.Producto;
import java.util.*;

public class ProductoDAO implements IBaseDAO<Producto> {
    private List<Producto> productos = new ArrayList<>();

    public void insertar(Producto producto) { productos.add(producto); }

    public void actualizar(Producto producto) {
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getId() == producto.getId()) {
                productos.set(i, producto);
                return;
            }
        }
    }

    public void eliminar(int id) {
        productos.removeIf(p -> p.getId() == id);
    }

    public Producto obtenerPorId(int id) {
        return productos.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    public List<Producto> obtenerTodos() { return productos; }
}
