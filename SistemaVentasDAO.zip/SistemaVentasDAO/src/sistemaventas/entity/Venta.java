
package sistemaventas.entity;

import java.util.Date;

public class Venta {
    private int id;
    private int clienteId;
    private Date fecha;

    public Venta(int id, int clienteId, Date fecha) {
        this.id = id;
        this.clienteId = clienteId;
        this.fecha = fecha;
    }

    public int getId() { return id; }
    public int getClienteId() { return clienteId; }
    public Date getFecha() { return fecha; }
}
