
package sistemaventas.entity;

public class DetalleVenta {
    private int id;
    private int ventaId;
    private int productoId;
    private int cantidad;

    public DetalleVenta(int id, int ventaId, int productoId, int cantidad) {
        this.id = id;
        this.ventaId = ventaId;
        this.productoId = productoId;
        this.cantidad = cantidad;
    }

    public int getId() { return id; }
    public int getVentaId() { return ventaId; }
    public int getProductoId() { return productoId; }
    public int getCantidad() { return cantidad; }
}
